#include <stdbool.h>
#include <stdlib.h>

#include "counter.h"

struct _counter {
    unsigned int count;
};

counter counter_init(void) {
/*
    Needs implementation.
*/
}

void counter_inc(counter c) {
/*
    Needs implementation.
*/
}

bool counter_is_init(counter c) {
/*
    Needs implementation.
*/
}

void counter_dec(counter c) {
/*
    Needs implementation.
*/
}

counter counter_copy(counter c) {
/*
    Needs implementation.
*/
}

void counter_destroy(counter c) {
/*
   Needs implementation.
*/
}
